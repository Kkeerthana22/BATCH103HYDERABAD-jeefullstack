package com.capg.seleniumbdd.seleniumi_iconnectpage_test;

import static org.junit.Assert.*;

import org.junit.Test;

public class iconnect {

	

}
