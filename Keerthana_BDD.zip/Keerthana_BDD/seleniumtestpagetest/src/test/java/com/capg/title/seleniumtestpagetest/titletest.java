package com.capg.title.seleniumtestpagetest;

import static org.junit.Assert.assertEquals;

import java.util.logging.Logger;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class titletest {

	
	
	 WebDriver driver;
	
	@Test
	public void pagetest() {
		try {
		System.setProperty("webdriver.chrome.driver","D:\\Srinivas-BDD\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		
		driver.get("http://localhost:8081/seleniumtestpagehtml/title.html");
		Thread.sleep(2000);
/*if(driver.getTitle().equals("capg")) {
	System.out.println("validated title");
}
else {
	System.out.println("not validated");
}*/
String txt = driver.findElement(By.id("text")).getAttribute("value");
	assertEquals("capgemini",txt);
	if(txt.equals("capgemini")) {
		System.out.println("success");
	}
	else
	{
		System.out.println("failed");
	}

}
		catch (Exception e) {
			// TODO: handle exception
		}

}
}

	
