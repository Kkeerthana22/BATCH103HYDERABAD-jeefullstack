package com.capg.log.log4J;

import org.apache.log4j.Logger;

/**
 * Hello world!
 *
 */
public class App 
{
   
        //System.out.println( "Hello World!" );
    	static Logger logger =Logger.getLogger(App.class.getName());
    	public static void main(String[] args) {
    		
			logger.info("Hi keerthana");
			logger.warn("please check the warning");
			logger.error("please check the error");
			logger.fatal("please check the fatal");
			
		}
    	
    }

