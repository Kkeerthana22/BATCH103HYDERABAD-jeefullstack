package com.capg.seleniumtest.selenium_Test_conference_page;

import java.util.logging.Logger;

import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class conferencepagetest {

	static Logger logger = Logger.getLogger("AlertExamp.class");
	static WebDriver driver;
	
	@Test
	public void pagetest() {
		try {
		System.setProperty("webdriver.chrome.driver","D:\\Srinivas-BDD\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8081/selenium_conferencepagehtml/conference.html");
		Thread.sleep(2000);

		driver.findElement(By.name("txtFN")).sendKeys("keerthana");
		driver.findElement(By.name("txtLN")).sendKeys("Karnati");
		driver.findElement(By.name("Email")).sendKeys("Keerthihope22@gmail.com");
		driver.findElement(By.name("Phone")).sendKeys("9553977751");
		
		WebElement element=driver.findElement(By.name("size"));
		Select se=new Select(element);
		se.selectByVisibleText("4");
		
		driver.findElement(By.name("Address")).sendKeys("45");
		driver.findElement(By.name("Address2")).sendKeys("raghavendra colony");
	
		Select c = new Select (driver.findElement(By.name("city")));
		c.selectByValue("Hyderabad");
		
		WebElement es =driver.findElement(By.name("state"));
		Select st =new Select(es);
		st.selectByValue("Telangana");
		
		 driver.findElement(By.name("memberStatus")).click();
		 driver.findElement(By.linkText("Next")).click();
		
		
		Alert alert=driver.switchTo().alert();
		logger.info(alert.getText());
		alert.accept();
		
		driver.get("http://localhost:8081/selenium_conferencepagehtml/paymentdetails");
		Thread.sleep(2000);

		driver.findElement(By.name("txtFN")).sendKeys("keerthana");
		driver.findElement(By.name("debit")).sendKeys("123456789");
		driver.findElement(By.name("cvv")).sendKeys("233");
		driver.findElement(By.name("month")).sendKeys("febrauary");	
		
		driver.findElement(By.name("year")).sendKeys("2022");	
		driver.findElement(By.id("btnPayment")).click();
		Alert alert1=driver.switchTo().alert();
		logger.info(alert1.getText());
		alert1.accept();
		
		logger.info("done");
		
	
	
	
}
		catch (Exception e) {
			// TODO: handle exception
		}
}
}
