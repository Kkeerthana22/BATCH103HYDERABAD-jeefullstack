package com.capgemini.bankwallet.test;

public class BankWalletTest {



}
