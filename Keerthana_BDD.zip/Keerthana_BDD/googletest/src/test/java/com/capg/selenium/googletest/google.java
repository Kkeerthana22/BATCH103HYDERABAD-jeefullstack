package com.capg.selenium.googletest;

import static org.junit.Assert.*;

import java.util.logging.Logger;

import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class google {

	WebDriver driver;
	 static Logger logger =Logger.getLogger(google.class.getName());
		
		@Test
		public void ExampleForAlert() throws InterruptedException{
			System.setProperty("webdriver.chrome.driver","D:\\Srinivas-BDD\\Selenium\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://www.google.com");
			Thread.sleep(2000);
			driver.findElement(By.name("q")).sendKeys("keerthana");
			driver.findElement(By.name("btnk")).sendKeys(Keys.ENTER);
			Alert alert=driver.switchTo().alert();
			logger.info(alert.getText());
			
						alert.accept();
						logger.info("done");
			

}
}
